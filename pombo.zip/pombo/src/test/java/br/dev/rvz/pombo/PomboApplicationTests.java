package br.dev.rvz.pombo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PomboApplicationTests {

	@Test
	void contextLoads() {
	}

}
