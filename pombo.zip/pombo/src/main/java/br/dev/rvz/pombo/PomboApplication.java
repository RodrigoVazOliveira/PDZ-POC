package br.dev.rvz.pombo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PomboApplication {

	public static void main(String[] args) {
		SpringApplication.run(PomboApplication.class, args);
	}

}
